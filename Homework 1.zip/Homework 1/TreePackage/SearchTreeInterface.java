//
//  Name:       Trinh, Michael
//  Homework:   1
//  Due:        October 25,2017
//  Course:     cs-241-02-f17
//
//  Description:    
//              Implement the ADT dictionary using a BST and use it as a 
//                  word count program.
//

package TreePackage;
import java.util.Iterator;

public interface SearchTreeInterface<T extends Comparable<? super T>>
                 extends TreeInterface<T>
{
    
/** Searches for a specific entry in this tree.
@return true if the object was found in the tree */
    
public boolean contains(T entry);

/** Retrieves a specific entry in this tree.
@param entry an object to be found
@return either the object that was found in the tree or
null if no such object exists */

public T getEntry(T entry);

/** Adds a new entry to this tree.
If the entry matches an object that exists in the tree
already, replaces the object with the new entry.
@param newEntry an object to be added to the tree
@return either null if newEntry was not in the tree already, or
an existing entry that matched the parameter newEntry
and has been replaced in the tree */

public T add(T newEntry);

/** Removes a specific entry from this tree.
@param entry an object to be removed
@return either the object that was removed from the tree or
null if no such object exists */

public T remove(T entry);

/** Creates an iterator that traverses all entries in this tree.
@return an iterator that provides sequential and ordered access
to the entries in the tree */

public Iterator<T> getInorderIterator();

} // end SearchTreeInterface